//Menu button

//Home

var login,home;
 login = document.getElementById("home-menu");
 login.onclick = function(){
     home = intro.html;
     window.open(home,'');
};

//About us

var About_Us,About_Us_1;
 About_Us = document.getElementById("at-a-glance-about-us-menu");
 About_Us.onclick = function(){
    About_Us_1= At_A_glance.html;
    window.open(About_Us_1,'');
};

//At A Glance

var At_A_Glance,At_A_Glance_1;
 At_A_Glance = document.getElementById("at-a-glance-about-us-menu");
 At_A_Glance.onclick = function(){
    At_A_Glance_1 = At_A_glance.html;
    window.open(At_A_Glance_1,'');
};
